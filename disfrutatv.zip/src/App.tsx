import React, { useEffect } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import { StoreProvider } from "./context/store";
import Inicio from "./components/Inicio";
import Peliculas from "./components/Peliculas";
import Series from "./components/Series";
import MiContenido from "./components/MiContenido";
import MiPerfil from "./components/MiPerfil";
import Estadisticas from "./PanelAdmin/Estadisticas";
import Usuarios from "./PanelAdmin/Usuarios";
import Configuracion from "./PanelAdmin/Configuracion";
import NavBar from "./components/NavBar"; // Importar NavBar

import ProtectedRoute from "./components/ProtectedRoute"; // Importamos el componente de rutas protegidas
import PeliculasDetail from "./components/PeliculasDetail"; // Importa PeliculasDetail
import Login from "./components/Login"; // Importar el componente Login
import Register from "./components/Register"; // Importar la página de registro
import "@fortawesome/fontawesome-free/css/all.min.css";
import Footer from "./components/Footer";
import { AuthProvider } from "./context/AuthContext";
import SeriesDetail from "./components/SeriesDetail";
import RecuperarPass from "./components/RecuperarPass";
import ResetPass from "./components/ResetPass";

const App: React.FC = () => {
  // Asegurarse de que el modo oscuro esté habilitado al montar el componente
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <StoreProvider>
      <AuthProvider>
        <Router>
          <NavBar />
          <div className="bg-gray-900 text-white min-h-screen">
            <Routes>
              <Route path="/" element={<Inicio />} />
              <Route path="/peliculas" element={<Peliculas />} />
              <Route path="/peliculas/:id" element={<PeliculasDetail />} />{" "}
              <Route path="/series/:id" element={<SeriesDetail />} />{" "}
              {/* Ruta detalle película */}
              <Route path="/series" element={<Series />} />
              <Route path="/mi-contenido" element={<MiContenido />} />
              <Route path="/mi-perfil" element={<MiPerfil />} />
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/recuperar-contraseña" element={<RecuperarPass />} />
              <Route
                path="/resetear-contraseña/:token"
                element={<ResetPass />}
              />
              {/* Rutas protegidas */}
              <Route
                path="/admin/estadisticas"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <Estadisticas />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/usuarios"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <Usuarios />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/admin/configuracion"
                element={
                  <ProtectedRoute requiredRole="admin">
                    <Configuracion />
                  </ProtectedRoute>
                }
              />
            </Routes>
            <Footer />
          </div>
        </Router>
      </AuthProvider>
    </StoreProvider>
  );
};

export default App;
